# INEMA – Automação de Documentos

Projeto para geração automática de Word, Excel, PowerPoint e PDF
usando IA + código.
