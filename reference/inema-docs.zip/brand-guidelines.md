# INEMA – Brand Guidelines

## Identidade Visual
- Estilo: tecnológico, educacional, premium
- Tom: claro, profissional, acessível

## Cores
- Azul principal: #4DA3FF
- Azul escuro: #0B132B
- Branco: #FFFFFF

## Tipografia
- Títulos: Sans-serif moderna
- Corpo: Sans-serif legível

## Uso do Logo
- Sempre no topo ou capa
- Fundo escuro preferencial
