# Especificação de Documentos – INEMA

Criar automaticamente:
- Word institucional (2 páginas)
- Excel com abas de controle
- PowerPoint institucional
- PDF final
